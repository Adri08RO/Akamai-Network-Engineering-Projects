# app.py
from flask import Flask, render_template, request, redirect, url_for, session, flash
import os
import csv
import re
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from functools import wraps

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Change this in production

# Database setup
def init_db():
    conn = sqlite3.connect('security_incidents.db')
    c = conn.cursor()
    
    # Create users table
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY, 
                  username TEXT UNIQUE, 
                  password TEXT,
                  first_name TEXT,
                  last_name TEXT,
                  email TEXT,
                  user_type TEXT,  # 'employee' or 'customer'
                  title TEXT,      # for employees
                  company_name TEXT,  # for customers
                  address TEXT,
                  city TEXT,
                  state TEXT,
                  zip_code TEXT,
                  phone TEXT)''')
    
    # Create incidents table
    c.execute('''CREATE TABLE IF NOT EXISTS incidents
                 (id INTEGER PRIMARY KEY,
                  customer_id INTEGER,
                  attack_type TEXT,
                  source_ip TEXT,
                  count INTEGER,
                  start_time TEXT,
                  mac_address TEXT,
                  port INTEGER)''')
    
    # Insert sample data if not exists
    c.execute("SELECT COUNT(*) FROM users WHERE user_type='employee'")
    if c.fetchone()[0] == 0:
        # Sample employee
        c.execute("INSERT INTO users (username, password, first_name, last_name, email, user_type, title) VALUES (?, ?, ?, ?, ?, ?, ?)",
                  ('msato', generate_password_hash('password'), 'Mia', 'Sato', 'msato@lansharks.com', 'employee', 'President'))
        
        # Sample customer
        c.execute("""INSERT INTO users (username, password, first_name, last_name, email, user_type, company_name, 
                                        address, city, state, zip_code, phone) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                  ('dlaghari', generate_password_hash('password'), 'Dhruv', 'Laghari', 'dlaghari@mumbaitearoom.com', 
                   'customer', 'Mumbai Tea Room', 'E-13 Nand Dham Est, Marol Maroshi Road', 
                   'Mumbai', 'Maharashtra', '400059', '+91-1234567890'))
    
    conn.commit()
    conn.close()

init_db()

# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Process log files
def process_log_files():
    log_dir = os.path.join(os.path.dirname(__file__), 'logs')
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    processed_files = []
    
    for filename in os.listdir(log_dir):
        if filename.endswith('.csv'):
            filepath = os.path.join(log_dir, filename)
            
            # Extract customer number from filename
            match = re.match(r'(\d+)_', filename)
            if not match:
                continue
                
            customer_id = int(match.group(1))
            
            # Process the file
            incidents = analyze_csv(filepath, customer_id)
            
            # Save incidents to database
            conn = sqlite3.connect('security_incidents.db')
            c = conn.cursor()
            
            for incident in incidents:
                c.execute("""INSERT INTO incidents (customer_id, attack_type, source_ip, count, start_time, mac_address, port)
                             VALUES (?, ?, ?, ?, ?, ?, ?)""", 
                         (incident['customer_id'], incident['attack_type'], incident['source_ip'], 
                          incident['count'], incident['start_time'], incident.get('mac_address'), 
                          incident.get('port')))
            
            conn.commit()
            conn.close()
            
            # Rename the file
            new_name = f"{filename.split('.')[0]}_{datetime.now().strftime('%Y%m%d%H%M%S')}.old"
            os.rename(filepath, os.path.join(log_dir, new_name))
            processed_files.append(filename)
    
    return processed_files

# Analyze CSV for security incidents
def analyze_csv(filepath, customer_id):
    incidents = []
    
    with open(filepath, 'r') as file:
        reader = csv.DictReader(file)
        
        # Check for ARP poisoning
        arp_data = {}
        for row in reader:
            if row.get('Protocol') == 'ARP' and 'Info' in row:
                # Extract MAC and IP from Info field
                info = row['Info']
                mac_match = re.search(r'([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})', info)
                ip_match = re.search(r'\b(?:\d{1,3}\.){3}\d{1,3}\b', info)
                
                if mac_match and ip_match:
                    mac = mac_match.group(0)
                    ip = ip_match.group(0)
                    
                    if mac not in arp_data:
                        arp_data[mac] = {'ips': set(), 'time': row.get('Time', '')}
                    
                    arp_data[mac]['ips'].add(ip)
        
        # Check for ARP poisoning (same MAC with multiple IPs)
        for mac, data in arp_data.items():
            if len(data['ips']) > 1:
                incidents.append({
                    'customer_id': customer_id,
                    'attack_type': 'ARP Poisoning',
                    'source_ip': ', '.join(data['ips']),
                    'count': len(data['ips']),
                    'start_time': data['time'],
                    'mac_address': mac
                })
        
        # Reset file pointer to check for SYN flood
        file.seek(0)
        next(reader)  # Skip header
        
        syn_data = {}
        for row in reader:
            info = row.get('Info', '')
            if '[SYN]' in info and row.get('Source') == row.get('Destination'):
                # Extract port number
                port_match = re.search(r'\[SYN\].*?(\d+)', info)
                if port_match:
                    port = port_match.group(1)
                    if port not in syn_data:
                        syn_data[port] = {'count': 0, 'time': row.get('Time', '')}
                    
                    syn_data[port]['count'] += 1
        
        # Add SYN flood incidents
        for port, data in syn_data.items():
            if data['count'] > 10:  # Threshold for SYN flood
                incidents.append({
                    'customer_id': customer_id,
                    'attack_type': 'SYN Flood',
                    'source_ip': 'Multiple',
                    'count': data['count'],
                    'start_time': data['time'],
                    'port': port
                })
    
    return incidents

# Routes
@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        is_employee = 'employee' in request.form
        
        conn = sqlite3.connect('security_incidents.db')
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username = ?", (username,))
        user = c.fetchone()
        conn.close()
        
        if user and check_password_hash(user[2], password):
            user_type = user[6]  # user_type field
            
            if is_employee and user_type != 'employee':
                return render_template('error.html', 
                                      message="Something Went Wrong",
                                      details="If you are an employee, make sure you checked the employee box on the login page. If you are not, please do not check the box.")
            
            session['user_id'] = user[0]
            session['username'] = user[1]
            session['user_type'] = user_type
            session['first_name'] = user[3]
            session['last_name'] = user[4]
            
            if user_type == 'employee':
                return redirect(url_for('employee_dashboard'))
            else:
                return redirect(url_for('customer_dashboard'))
        else:
            return render_template('error.html', 
                                  message="Authentication Failed",
                                  details="Click here to retry.")
    
    return render_template('login.html')

@app.route('/employee/dashboard')
@login_required
def employee_dashboard():
    if session['user_type'] != 'employee':
        return redirect(url_for('login'))
    
    conn = sqlite3.connect('security_incidents.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE id = ?", (session['user_id'],))
    user = c.fetchone()
    conn.close()
    
    return render_template('employee_dashboard.html', 
                          user=user,
                          first_name=session['first_name'],
                          last_name=session['last_name'])

@app.route('/customer/dashboard')
@login_required
def customer_dashboard():
    if session['user_type'] != 'customer':
        return redirect(url_for('login'))
    
    # Process any new log files
    process_log_files()
    
    conn = sqlite3.connect('security_incidents.db')
    c = conn.cursor()
    
    # Get customer info
    c.execute("SELECT * FROM users WHERE id = ?", (session['user_id'],))
    user = c.fetchone()
    
    # Get incidents for this customer
    c.execute("SELECT * FROM incidents WHERE customer_id = ?", (session['user_id'],))
    incidents = c.fetchall()
    conn.close()
    
    return render_template('customer_dashboard.html', 
                          user=user,
                          incidents=incidents,
                          first_name=session['first_name'],
                          last_name=session['last_name'])

@app.route('/change_password', methods=['GET', 'POST'])
@login_required
def change_password():
    if request.method == 'POST':
        old_password = request.form['old_password']
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']
        
        if new_password != confirm_password:
            return render_template('error.html', 
                                  message="Something Went Wrong",
                                  details="Your password was not changed. New passwords do not match.")
        
        conn = sqlite3.connect('security_incidents.db')
        c = conn.cursor()
        c.execute("SELECT password FROM users WHERE id = ?", (session['user_id'],))
        current_hash = c.fetchone()[0]
        
        if not check_password_hash(current_hash, old_password):
            return render_template('error.html', 
                                  message="Something Went Wrong",
                                  details="Your password was not changed. Current password is incorrect.")
        
        # Update password
        new_hash = generate_password_hash(new_password)
        c.execute("UPDATE users SET password = ? WHERE id = ?", (new_hash, session['user_id']))
        conn.commit()
        conn.close()
        
        return render_template('success.html', 
                              message="Password Changed!",
                              details=f"{session['first_name']} {session['last_name']}, you have successfully changed your password!")
    
    return render_template('change_password.html', 
                          first_name=session['first_name'],
                          last_name=session['last_name'],
                          username=session['username'])

@app.route('/update_contact', methods=['GET', 'POST'])
@login_required
def update_contact():
    if session['user_type'] != 'customer':
        return redirect(url_for('login'))
    
    conn = sqlite3.connect('security_incidents.db')
    c = conn.cursor()
    
    if request.method == 'POST':
        company_name = request.form['company_name']
        address = request.form['address']
        city = request.form['city']
        state = request.form['state']
        zip_code = request.form['zip_code']
        email = request.form['email']
        phone = request.form['phone']
        
        c.execute("""UPDATE users SET company_name=?, address=?, city=?, state=?, zip_code=?, email=?, phone=?
                     WHERE id=?""", 
                  (company_name, address, city, state, zip_code, email, phone, session['user_id']))
        conn.commit()
        conn.close()
        
        return render_template('success.html', 
                              message="Contact Information Updated!",
                              details=f"{session['first_name']} {session['last_name']}, you have successfully changed your contact information!")
    
    c.execute("SELECT * FROM users WHERE id = ?", (session['user_id'],))
    user = c.fetchone()
    conn.close()
    
    return render_template('update_contact.html', user=user)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)